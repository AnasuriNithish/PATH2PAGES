// src/Journal.jsx

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ShoppingCart, ChevronLeft, ChevronRight } from "lucide-react";
import { FaWhatsapp, FaInstagram } from "react-icons/fa";
import { SiThreads } from "react-icons/si";

const PRODUCT_ID = "68d8f374e1f41bc52a3185e2";
const CART_KEY = "pathtopages_cart"; // keep same key used by Cart.jsx

// Product data for the main journal
const product = {
  id: PRODUCT_ID,
  title: "Journal Book",
  description:
    "An exquisite, vintage journal crafted with 200 pages of beautifully aged, premium parchment-style paper. Perfect for capturing wandering thoughts, documenting timeless travel tales, or planning your days with old-world charm and elegance..",
  price: 799,
  details: [
    "Travel Journal Book",
    "Color Craft Papers",
    "Sketching Pencil",
    "Elegant Bookmark Collection",
    "Precision Craft Scissors",
    "Pastel Sticky Note Pack",
    "Creative Sticker Set",
    "Artist’s Color Pencil Kit",
    "Strong Hold Craft Glue",
    "Pocket-Sized Mini Notebook",
    "Genuine leather cover (mock)",
    "Hand-stitched binding",
  ],
  images: [
    `${process.env.PUBLIC_URL}/IMG-20251027-WA0006.jpg`,
    `${process.env.PUBLIC_URL}/IMG-20251027-WA0005.jpg`,
    `${process.env.PUBLIC_URL}/IMG-20251027-WA0010.jpg`,
  ],
};

const formatCurrency = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
  }).format(amount);

// Inject Bootstrap + page-specific minimal scrapbook styling
const CustomStyles = () => (
  <>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      crossOrigin="anonymous"
    />
    <style>
      {`
        body {
          background-color: #f8f5ed;
          font-family: "Lora", serif;
          color: #3e2723;
        }

        .page-bg {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
        }

        .main-content {
          flex: 1;
        }

        /* NAVBAR */
        .journal-navbar {
          background: #7a5c4d;
          border-bottom: 2px dashed #f8ead8;
          box-shadow: 0 4px 12px rgba(58, 37, 18, 0.35);
        }

        .journal-navbar .brand-text {
          color: #fff8f0;
        }

        .journal-navbar .nav-link-custom {
          color: #f8ead8 !important;
          font-weight: 500;
        }

        .journal-navbar .nav-link-custom:hover {
          color: #ffe6b3 !important;
        }

        .cart-icon {
          color: #fff8f0;
        }

        .cart-link:hover .cart-icon {
          color: #ffe6b3;
        }

        /* CONTENT */
        h1, h2, h4, h5 {
          color: #4a2e20;
        }

        .vintage-card-shadow {
          border-radius: 10px;
          background: #fffdf8;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.06);
        }

        .text-vintage-accent {
          color: #a35d48 !important;
        }

        .btn-vintage {
          background-color: #a35d48;
          border: none;
          color: white;
          padding: 8px 18px;
          border-radius: 6px;
        }

        .btn-vintage:hover {
          background-color: #8c4c3e;
        }

        .carousel-image {
          width: 100%;
          height: 500px;
          object-fit: cover;
          border-radius: 10px;
        }

        /* FOOTER */
        .journal-footer {
          background: #7a5c4d;
          color: #fdf8f3;
          border-top: 2px dashed #f8ead8;
          padding: 2rem 1.5rem;
        }

        .journal-footer h4 {
          color: #ffe6b3;
        }

        .journal-footer .footer-link {
          color: #fceac7;
          text-decoration: none;
          font-size: 0.95rem;
        }

        .journal-footer .footer-link:hover {
          color: #ffe6b3;
        }

        .journal-footer .social-icons a {
          font-size: 1.4rem;
          color: #ffe6b3;
          margin-left: 0.5rem;
        }

        .journal-footer .social-icons a:hover {
          color: #ffffff;
        }

        @media (max-width: 768px) {
          .carousel-image {
            height: 320px;
          }
        }
      `}
    </style>
  </>
);

// Simple image carousel for journal pictures
const ProductImageCarousel = ({ images }) => {
  const [current, setCurrent] = useState(0);
  const total = images.length;

  const next = () => setCurrent((prev) => (prev + 1) % total);
  const prev = () => setCurrent((prev) => (prev - 1 + total) % total);

  return (
    <div className="position-relative vintage-card-shadow overflow-hidden">
      <img
        src={images[current]}
        alt={`Journal ${current + 1}`}
        className="carousel-image"
        onError={(e) => {
          e.target.onerror = null;
          e.target.src =
            "https://placehold.co/800x500/3e2723/f8f5ed?text=Image+not+found";
        }}
      />

      {/* Left / Right controls */}
      <button
        type="button"
        className="btn btn-sm bg-dark bg-opacity-50 text-white rounded-circle position-absolute top-50 start-0 translate-middle-y ms-3"
        onClick={prev}
      >
        <ChevronLeft size={22} />
      </button>
      <button
        type="button"
        className="btn btn-sm bg-dark bg-opacity-50 text-white rounded-circle position-absolute top-50 end-0 translate-middle-y me-3"
        onClick={next}
      >
        <ChevronRight size={22} />
      </button>

      {/* Indicators */}
      <div className="position-absolute bottom-0 start-50 translate-middle-x d-flex gap-2 mb-3">
        {images.map((_, i) => (
          <span
            key={i}
            onClick={() => setCurrent(i)}
            style={{
              width: 10,
              height: 10,
              borderRadius: "50%",
              cursor: "pointer",
              backgroundColor: current === i ? "#a35d48" : "#ffffff",
              opacity: current === i ? 1 : 0.6,
            }}
          />
        ))}
      </div>
    </div>
  );
};

const Journal = () => {
  const [quantity, setQuantity] = useState(1);
  const navigate = useNavigate();

  // Add to cart and go to /cart
  const handleAddToCart = () => {
    try {
      const existing = JSON.parse(localStorage.getItem(CART_KEY) || "[]");

      const index = existing.findIndex((item) => item.id === PRODUCT_ID);

      if (index > -1) {
        // Update quantity if already present
        existing[index].quantity += quantity;
      } else {
        // Push new line item
        existing.push({
          id: PRODUCT_ID,
          title: product.title,
          price: product.price,
          quantity,
          image: product.images[0],
        });
      }

      localStorage.setItem(CART_KEY, JSON.stringify(existing));

      // As per requirement: go directly to Cart page
      navigate("/cart");
    } catch (err) {
      console.error("Error adding to cart:", err);
      alert("Could not add item to cart. Please try again.");
    }
  };

  const handleQtyChange = (delta) => {
    setQuantity((prev) => Math.max(1, prev + delta));
  };

  return (
    <div className="page-bg">
      <CustomStyles />

      {/* NAVBAR */}
      <nav className="navbar navbar-expand-lg px-3 py-2 journal-navbar fixed-top">
        <div className="container-fluid">
          <Link to="/" className="navbar-brand d-flex align-items-center">
            <img
              src={process.env.PUBLIC_URL + "/logo.png"}
              alt="PathToPages"
              height="38"
            />
            <span className="ms-2 fs-4 fw-semibold brand-text">
              PathToPages
            </span>
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#journalNav"
          >
            <span className="navbar-toggler-icon" />
          </button>

          <div className="collapse navbar-collapse" id="journalNav">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
              <li className="nav-item">
                <Link className="nav-link nav-link-custom px-3" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link nav-link-custom px-3" to="/shop">
                  Shop
                </Link>
              </li>
              <li className="nav-item">
                {/* My Account / Profile (Myaccount.jsx) */}
                <Link className="nav-link nav-link-custom px-3" to="/profile">
                  Profile
                </Link>
              </li>
              <li className="nav-item ms-3">
                <Link
                  to="/cart"
                  className="btn p-0 border-0 bg-transparent cart-link"
                >
                  <ShoppingCart size={24} className="cart-icon" />
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* MAIN CONTENT */}
      <main
        className="main-content"
        style={{ paddingTop: "110px", paddingBottom: "30px" }}
      >
        <div className="container">
          <div className="row g-5">
            {/* Images section */}
            <div className="col-lg-6">
              <ProductImageCarousel images={product.images} />
            </div>

            {/* Product details section */}
            <div className="col-lg-6">
              <div className="card p-4 vintage-card-shadow border-0 h-100">
                <div className="card-body d-flex flex-column">
                  <h1 className="h2 mb-2">{product.title}</h1>
                  <p className="text-uppercase small fw-bold text-vintage-accent mb-3">
                    Handbound Collection
                  </p>

                  <p className="text-muted">{product.description}</p>

                  <div className="mt-4">
                    <h5 className="mb-2">Key Features</h5>
                    <ul className="list-unstyled text-muted small ms-3">
                      {product.details.map((d, i) => (
                        <li key={i} className="mb-1">
                          • {d}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Price & Add to Cart */}
                  <div className="mt-auto pt-4 border-top">
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <span className="h3 text-vintage-accent fw-bold">
                        {formatCurrency(product.price)}
                      </span>
                    </div>

                    <div className="d-flex align-items-center gap-3">
                      {/* Quantity selector */}
                      <div className="input-group" style={{ maxWidth: 120 }}>
                        <button
                          type="button"
                          className="btn btn-outline-secondary"
                          onClick={() => handleQtyChange(-1)}
                        >
                          -
                        </button>
                        <input
                          type="number"
                          className="form-control text-center"
                          min="1"
                          value={quantity}
                          onChange={(e) =>
                            setQuantity(
                              Math.max(1, parseInt(e.target.value) || 1)
                            )
                          }
                        />
                        <button
                          type="button"
                          className="btn btn-outline-secondary"
                          onClick={() => handleQtyChange(1)}
                        >
                          +
                        </button>
                      </div>

                      {/* Add to Cart button */}
                      <button
                        type="button"
                        className="btn btn-vintage flex-grow-1 d-flex align-items-center justify-content-center gap-2"
                        onClick={handleAddToCart}
                      >
                        <ShoppingCart size={20} />
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="journal-footer mt-4">
        <div className="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
          <div>
            <h4 className="mb-1">Path To Pages</h4>
            <span className="small">Scrapbook journal market</span>
          </div>

          <div className="d-flex flex-column flex-md-row align-items-center gap-3">
            <ul className="list-unstyled d-flex flex-wrap gap-3 mb-0">
              <li>
                <Link to="/" className="footer-link">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/shop" className="footer-link">
                  Shop
                </Link>
              </li>
              <li>
                <Link to="/profile" className="footer-link">
                  Profile
                </Link>
              </li>
              <li>
                <Link to="/cart" className="footer-link">
                  Cart
                </Link>
              </li>
            </ul>

            <div className="social-icons d-flex">
              <a
                href="https://wa.me/918019418800"
                target="_blank"
                rel="noreferrer"
              >
                <FaWhatsapp />
              </a>
              <a
                href="https://www.instagram.com/pathtopages"
                target="_blank"
                rel="noreferrer"
              >
                <FaInstagram />
              </a>
              <a
                href="https://www.threads.net/pathtopages"
                target="_blank"
                rel="noreferrer"
              >
                <SiThreads />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Journal;
